#include<stdio.h>
#include"head.h"

void four(){
	printf("FIRST FUNCTION DONE \n");
	}
