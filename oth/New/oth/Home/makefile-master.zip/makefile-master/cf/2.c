#include<stdio.h>
#include"head.h"

void second(){
	printf("FIRST FUNCTION DONE \n");
	}
