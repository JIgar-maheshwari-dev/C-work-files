#include<stdio.h>
#include"head.h"

void third(){
	printf("FIRST FUNCTION DONE \n");
	}
