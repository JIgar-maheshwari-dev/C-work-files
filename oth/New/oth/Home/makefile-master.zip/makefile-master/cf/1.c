#include<stdio.h>
#include"head.h"

void first(){
	printf("FIRST FUNCTION DONE \n");
	}
