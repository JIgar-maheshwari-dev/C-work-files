int h1f(int a,int b);
int h2f(int a,int b);
