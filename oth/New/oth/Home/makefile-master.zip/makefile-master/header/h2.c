#include"head.h"

int h2f(int a,int b){
	return (a+b);
}
