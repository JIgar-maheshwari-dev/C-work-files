#include"head.h"

int h1f(int a,int b){
	return (a+b);
}
