int lib1fun(int a,int b);
int lib2fun(int a,int b);
