#include"libs.h"

int lib2fun(int a,int b){
	return (a+b);
	}
