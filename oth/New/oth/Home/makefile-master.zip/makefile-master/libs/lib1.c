#include"libs.h"

int lib1fun(int a,int b){
	return (a+b);
	}
