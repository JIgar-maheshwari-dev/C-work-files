int sampleAdd(int a, int b);
