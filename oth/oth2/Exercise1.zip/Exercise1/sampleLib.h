int sampleMultiply(int a, int b);
