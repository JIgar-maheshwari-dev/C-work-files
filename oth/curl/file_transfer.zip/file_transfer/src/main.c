#include<stdio.h>
#include"head.h"

int main() {

	send1();

	return 0;
}

